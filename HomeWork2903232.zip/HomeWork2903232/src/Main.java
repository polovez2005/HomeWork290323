import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("введите название блюда : ");
        String dish = scanner.nextLine();

        switch (dish.toLowerCase()){

            case "Шашльік":
                System.out.println("Состав: мясо, маринад, лук");
                break;
            case "Шурпа":
                System.out.println("Состав: мясо, картофель, морковь, лук");
                break;
            case "борщ":
                System.out.println("Состав: мясо, буряк, томат, морква, картофель, лук ");
                break;
            case "Жаркое":
                System.out.println("Состав: мясо, картофель, морква, лук");
                break;
            case "Вареники":
                System.out.println("Состав:тесто, мясо, картофель, сметана");
                break;
            case "Суп":
                System.out.println("Состав: мясо, катрафель, лук, морква");
                break;
            case "Жареньій картофель":
                System.out.println("Состав: мясо, картофель, лук");
                break;
            case  "Рагу":
                System.out.println("Состав: мясо, баклажан, картофель, лук, морква");
                break;

            default:
                System.out.println("Состав отсутствует");
        }

    }
}