import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Ввести число : ");

        int arg1 = scanner.nextInt();
        int arg2 = scanner.nextInt();
        System.out.println("значение 1 и 2 бьіло :" + arg1 + "и" + arg2 );

        arg1 = arg1 ^ arg2;
        arg2 = arg1 ^ arg2;
        arg1 = arg1 ^ arg2;

        System.out.println("значение 1 и 2 стало:" + arg1 + "и" + arg2 );


        }

}