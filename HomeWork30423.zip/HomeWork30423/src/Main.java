import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int[] arreyNum = {334,43,54,100,999,54,9808,3212,55,90};
        System.out.println("корекция по возрастанию введите слово 'true':");
        System.out.println("корекция по убьіванию введите слово 'false':");
        boolean isIncrease = scanner.nextBoolean();
        sortiren(arreyNum, isIncrease);
    }
    public static void sortiren(int[] num, boolean isIncrease){
        int numb = 0;
        if (isIncrease){
            for (int index = 0; index < num.length -1; index++ ){
                for (int indexJ = 1; indexJ < num.length; indexJ++)
                if (num[index] > num[indexJ] ) {
                    numb = num[index];
                    num[index] = num[indexJ];
                    num[indexJ] = numb;

                }
            }
        }
        else{
            for (int index = 0; index < num.length -1; index++){
                for (int indexJ = index+1; indexJ < num.length; indexJ++){
                    if(num[index] < num[indexJ]){
                        numb =num[index];
                        num[index] = num[indexJ];
                        num[indexJ] = numb;
                    }
                }
            }
        }
        for (int number : num){
            System.out.print(number + " ");
        }


    }
}


