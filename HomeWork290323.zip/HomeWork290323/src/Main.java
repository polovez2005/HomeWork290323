public class Main {
    public static void main(String[] args) {


        Fruit[] fruits = {
                new Fruit("apple", true, "green"),
                new Fruit("cherry", true, "red/white/black"),
                new Fruit("banana", true, "yellow/green")
        };



        //   (Переменная для хран. фруктов) : (название массива с фруктами)
        for (int i =0 ; i< fruits.length; i++ ){
            System.out.println("Iteration: " + i);
            System.out.println("Fruit name: " + fruits[i].name);
            System.out.println("Fruit color: " + fruits[i].color);
            System.out.println("Fruit is tasty?: " + fruits[i].isTasty);

        }

    }
}