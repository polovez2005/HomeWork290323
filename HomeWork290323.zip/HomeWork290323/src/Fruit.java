public class Fruit {

    String name = "";
    String color = "";

    boolean isTasty;
    Fruit (String name, boolean isTasty, String color){
        this.name = name;
        this.isTasty = isTasty;
        this.color = color;
    }

}
