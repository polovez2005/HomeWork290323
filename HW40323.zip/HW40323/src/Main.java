import java.util.Scanner;
public class Main {
    public static void main(String[] args) {


        Scanner scanner = new Scanner(System.in);
        System.out.println("Ввести числа : ");

        int arg1 = scanner.nextInt();
        int arg2 = scanner.nextInt();
        int result = arg1 + arg2;
        int result0 = arg1 - arg2;
        int result1 = arg1 * arg2;
        int result2 = arg1 / arg2;

        System.out.println("сумма чисел при сложении : " + "=" + result);
        System.out.println("сумма чисел при отнимании : " + "=" + result0);
        System.out.println("сумма чисел при умножении : " + "=" + result1);
        System.out.println("сумма чисел при делении : " + "=" + result2);{

            boolean bool = true;
            int arg = 1976;
            String str = "Ввод переменньіх";
            double argt = 3.14;
            System.out.println(bool);
            System.out.println(arg);
            System.out.println(str);
            System.out.println(argt);



        }



    }

}





