import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Ввести число 1 : ");
        int arg1 = scanner.nextInt();

        System.out.println("Ввести число 2 : ");
        int arg2 = scanner.nextInt();

        int result = arg1 +arg2;

        boolean isOdd = result % 2  != 0;

        System.out.println("Сумма чисел :"  + result + " " + (isOdd ?  "не четное" : "четное"));

    }
}