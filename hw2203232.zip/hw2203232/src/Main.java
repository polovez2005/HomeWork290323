import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        boolean result = false;
        boolean isPlanetSave;
        int danger = 0;

        System.out.println("Анализ рисков для планетьі :");
        System.out.println("Ответить на вопросьі по шкале от 1 до 5\n");

        System.out.println("Угроза мировой войньі - > ");
        boolean worldWar = isAnswerQuestion(scan);

        System.out.println("Угроза ядерной войньі - > ");
        boolean nuсlearWar = isAnswerQuestion(scan);

        System.out.println("Угроза техногеной катастрофьі - > ");
        boolean technoDisaster = isAnswerQuestion(scan);

        System.out.println("Загрязнение Єкологии - > ");
        boolean ecoDisaster = isAnswerQuestion(scan);

        System.out.println("Мировой голод - > ");
        boolean worlHunger = isAnswerQuestion(scan);

        System.out.println("Загрязнение питьевой водьі - > ");
        boolean waterScarcity = isAnswerQuestion(scan);

        System.out.println("Мировая пандемия - > ");
        boolean globalPandemic = isAnswerQuestion(scan);

        System.out.println("Изменение климата - > ");
        boolean changingKlimate = isAnswerQuestion(scan);

        System.out.println("Вьімирание флорьі и фауньі- > ");
        boolean extinctionOfLive = isAnswerQuestion(scan);

        System.out.println("Угроза падения метеорита - > ");
        boolean meteorFalling = isAnswerQuestion(scan);
        System.out.println();

        boolean risico = worldWar || nuсlearWar || technoDisaster || ecoDisaster || worlHunger || waterScarcity
                || globalPandemic || changingKlimate || extinctionOfLive;

        System.out.println("Анализ рисков :" + (risico ? "Опасность" : "Безопасно"));

        System.out.println("Угроза падения метеорита ? (1-да 0-нет )");
        danger = scan.nextInt();

        if (risico && danger == 1) System.out.println("Планета погибла!");
        else if (risico || danger == 1) {
            System.out.println("Есть шанс на спасение? (1-да 0-нет)");
            int helpPlanet = scan.nextInt();

            if (helpPlanet == 0) {
                System.out.println("Планета погибла!");
            } else {
                System.out.println("Планета спасена!");
            }
        } else {
            System.out.println("Жизнь продолжается");
        }
    }public static boolean isAnswerQuestion(Scanner scanner){
        int risk = scanner.nextInt();
        if (risk >=3) return false;
        return true;

            }
        }







